class Config(object):
    SOLR_ADDRESS = 'http://164.92.243.172:8983/solr/sease'
    OPENAI_API_KEY = "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"
    LARGE_LANGUAGE_MODEL = "gpt-3.5-turbo-instruct"
